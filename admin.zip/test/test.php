




<img src="../user_management/serve.php?file_path=images/reports/reportid.extension" alt="Protected Image">
